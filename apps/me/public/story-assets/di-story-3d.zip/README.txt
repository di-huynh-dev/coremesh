Bo mo hinh 3D - Chuyen cua Di (me.nextdi.io.vn/story)

Thu muc scenes/     : 11 boi canh sa ban (01-que-nha.glb ... 11-coi-nguon.glb)
Thu muc characters/ : nhan vat Di theo tung chang (nhan-vat-di-<chang>.glb), co animation di bo

Dinh dang: binary glTF 2.0 (.glb), mo bang Blender, three.js, Babylon.js, Windows 3D Viewer.
Don vi: 1 don vi = 1 don vi mo hinh, truc Y huong len.
